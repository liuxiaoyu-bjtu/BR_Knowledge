# K1足球检测结果到身体坐标：静态只读测试

本工具回答：检测得到足球后，补上深度和内参，能否经SDK的`get_transform()`算出合理的身体参考球位。一次运行只采集一组静态快照，并保存计算过程，供卷尺比较。无需教师JSON，也不依赖`k1_soccer.py`。

本次交付工具并完成离线模拟检查，未运行机器人；真实输出由现场运行产生。本工具不调用头部、速度、模式或SoccerKickManager。

## 1. 先区分像素与米制坐标

`Detection.detect()`输出的bbox是像素，`get_transform()`返回的是两个三维坐标系之间的变换矩阵。因此实际链路为：

```text
Ball检测框(u,v，像素)
  → 在同一快照的配准深度中取足球区域
  → 用深度Z和内参K反投影为相机三维点（米）
  → 拟合足球球心p_camera
  → p_trunk = T_trunk←camera @ [p_camera.x, p_camera.y, p_camera.z, 1]
```

针孔模型且像素无畸变时，反投影为：

```python
Xc = (u - cx) / fx * Z
Yc = (v - cy) / fy * Z
Zc = Z
```

若存在SDK内参支持的畸变模型，本工具先用OpenCV去畸变计算射线。深度默认按光轴Z解释；如果实际是沿射线量程，需要改用单位射线计算，不能混用。

检测框中心对应的深度常落在可见球面。为了比较球心，本工具在框内中心椭圆区域取点，拟合球面，并同时保存拟合半径、残差与表面点统计。拟合失败时保留原图与深度，不将表面点改称球心。

## 2. 现场准备

1. 使用已有能运行BoosterOS SDK与`soccer`检测模型的机器人开发环境。保持机器人、头部和球静止；停止此前足球程序与其他运动程序。无需为了本测试切换模式或行走。
2. 让球在当前视野内。画面里保留一颗球，避免手、脚或其他物体遮挡。
3. 把本目录复制到开发环境。打开`K1足球坐标_只读测试.ipynb`，或运行同目录的`probe_ball_coordinates.py`。
4. 默认`camera_id="head"`、`target_frame="trunk"`来自本机已取得清单。相机source帧取本次RGB的`header.frame_id`，不写死相机光学帧名称。

**深度比例默认0.001，是本次诊断的毫米候选假设。** 本机mono16/uint16本身不能证明单位；默认值也不表示单位已核实。RGB与深度同尺寸不能证明同像素配准。工具会明确保存这些假设；当前所有米制输出均为待核对候选值。

## 3. Jupyter运行

Notebook先导入并设置参数，再运行一次，最后显示选中球的图和关键结果。如果内核已有`robot`、`detector`，运行入口复用它们；若已有detector使用其他模型，应改传足球检测器，或将该参数设为None由工具创建soccer检测器。

直接调用也可以：

```python
from probe_ball_coordinates import run_probe

report = run_probe(
    robot=globals().get("robot"),
    detector=globals().get("detector"),  # 应为soccer模型
    depth_scale_m=0.001,                # 待核对的毫米候选假设
    known_xy=None,                     # 有量测值再填写，例如(实际x, 实际y)
    ball_radius_m=None,                # 可选，实球直径/2，单位米
    note="正前方，机器人/头部/球保持静止",
)
```

`known_xy`应使用本次目标坐标系的原点和轴向。以`trunk`为目标时，不要直接拿“球到脚尖/双脚中点的距离”作为trunk.x：两种原点可能有偏移。尚不清楚trunk物理原点时，先不填量测值，做左右符号与已知位移比较。

模块导入不连接机器人。调用时没有传入实例，才创建并缓存连接和检测器；同一内核重复调用会复用。工具不会自动关闭已有robot实例。

## 4. 终端运行

进入本目录，运行：

```bash
python3 probe_ball_coordinates.py --note "正前方静止球"
```

如已确定目标坐标系原点并实测球位，可传入比较值；以下数字仅演示参数格式：

```bash
python3 probe_ball_coordinates.py --known-xy 1.0 0.2 --ball-radius 0.09 --note "参数示例，须替换实测值"
```

`--depth-scale`可以更改比例，`--target`更改TF目标帧，`--output`更改结果父目录。不要在已连接机器人的Notebook中用`%run`反复执行终端入口。

## 5. 一次测试会显示和保存什么

控制台显示本次TF矩阵、选中球框、候选球心x/y/z、球面拟合半径和残差，最后打印结果目录与ZIP。检测前先保存配对RGB/深度，读取内参和TF；不会推理完成后再取另一张最新深度与旧框拼接。

```text
足球坐标测试结果/
  球位_日期_时间_微秒/
    原始记录.json
    采集汇总.md
    rgb.png、rgb_raw.npy
    depth_raw.npy                  收到深度时保存，原单位不改
    selected_ball.png              检出Ball且标注成功时保存
    TF本机公开实现.txt             本机源码可读时保存
    测试脚本.py
  球位_日期_时间_微秒.zip
```

发生错误时也保存已经取得的数据与异常，不补造缺失图片或坐标。将本次ZIP反馈即可，不需要手抄矩阵或每个接口输出。

| 字段 | 含义 |
| --- | --- |
| selected_ball | 实际选中球框与置信度；distance_m为空照实保存 |
| rgb_depth_skew_s | 深度时间减RGB时间；超过0.12秒会提示，0.12为诊断提示值，不是已验证验收标准 |
| transform.matrix | 请求`get_transform(target, source)`取得的4×4矩阵 |
| transform.returned_*_label | 原样保留SDK返回的source/target标签，便于检查已知标签歧义 |
| transform.tf_minus_rgb_s | TF时间减RGB时间；也保存推理耗时和结果产生时图像年龄 |
| reverse_transform.roundtrip_max_error | 双向TF的矩阵乘积与单位阵的最大差；只检查相互一致性，不能独立证明物理方向 |
| sphere_fit.center_camera_m | 相机光学坐标下拟合球心，单位米，采用已记录深度假设 |
| candidate_center_target_m | 目标帧下候选球心[x,y,z]，默认目标trunk |
| sphere_fit.fitted_radius_m / sphere_rms_m | 拟合半径与球面残差；可以和实球半径比较，不能仅凭残差小确认单位/配准正确 |
| surface_sample_median_target_m | 表面采样点统计，供诊断；不能直接当作球心 |
| measurement_comparison | 输入卷尺xy后，输出x/y偏差及平面误差；未自行设定通过阈值 |
| control_input_verified=false | 本工具未证明该结果已经符合踢球控制输入要求 |

`candidate_only`表示候选值已算出，`no_ball`表示未检出Ball，`error`表示某一步缺数据或计算失败，`interrupted`表示人工中断。运行结束不代表定位已经通过。

## 6. 怎样核对方向、比例与原点

每次保持机器人与头部不动，放球后再运行一次。先做以下位置比较，具体距离用现场量得的数值，不必使用固定位置或凑足指定帧数。

| 放球/移动方式 | 应比较的结果 | 可以发现什么 |
| --- | --- | --- |
| 机器人正前方 | 若目标帧x前y左，x应为正，y接近正前方对应值 | 轴向、横向偏移或选球错误 |
| 相近前后距离，球移到机器人左侧 | y应增加，单位为米 | 左右符号是否符合约定 |
| 球移到机器人右侧 | y应减小，右侧通常为负 | 符号与轴向是否反转 |
| 用卷尺将同一球向前移动已知距离Δx | 两次候选x的差应接近Δx | 比例、投影和TF是否有明显问题；差值比较可减轻固定原点偏移影响 |
| 测量实球半径 | 与拟合半径比较，同时查看原图、深度与残差 | 可能的单位错误、背景混入或深度质量问题 |

某次结果正好接近卷尺数值不能排除误差抵消。若要比较绝对坐标，需说明trunk的物理原点、轴向和卷尺量法；本工具没有将足底地面当成trunk.z=0。

后续若需要核对头部角度补偿，可在现有人工操作流程中更换头部角度，停稳后重采同一静止球，比较trunk坐标是否基本一致。本工具本身不控制转头。

## 7. 能否直接用于update_ball

本工具得到的是采集时刻、请求目标帧下的候选球心。`SoccerKickManager.update_ball()`需要当前控制身体坐标下的x/y。两者相接前，应先确认：

- 深度单位、光轴Z含义、彩深配准与球心取法成立。
- `get_transform()`矩阵的物理方向、trunk轴向及其与踢球控制原点的关系已核对。
- 机器人移动后仍有及时的球位流，近脚范围和遮挡不会使输入长期失效。

这份静态工具用于验证前面的数据和坐标关系。它不自动调用`update_ball()`，不将约2秒推理前的身体坐标冒充运动中的当前坐标。
